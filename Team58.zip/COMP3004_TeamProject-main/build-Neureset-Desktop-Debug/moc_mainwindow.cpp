/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../Neureset/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[31];
    char stringdata0[480];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 12), // "sessionStart"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 15), // "endSessionEarly"
QT_MOC_LITERAL(4, 41, 20), // "sessionPausedResumed"
QT_MOC_LITERAL(5, 62, 17), // "sessionStartCheck"
QT_MOC_LITERAL(6, 80, 18), // "updateBatteryLevel"
QT_MOC_LITERAL(7, 99, 5), // "level"
QT_MOC_LITERAL(8, 105, 10), // "batteryLow"
QT_MOC_LITERAL(9, 116, 20), // "batteryCriticallyLow"
QT_MOC_LITERAL(10, 137, 11), // "batteryNone"
QT_MOC_LITERAL(11, 149, 8), // "powerOff"
QT_MOC_LITERAL(12, 158, 20), // "confirmButtonPressed"
QT_MOC_LITERAL(13, 179, 17), // "playButtonPressed"
QT_MOC_LITERAL(14, 197, 18), // "pauseButtonPressed"
QT_MOC_LITERAL(15, 216, 17), // "stopButtonPressed"
QT_MOC_LITERAL(16, 234, 13), // "generateGraph"
QT_MOC_LITERAL(17, 248, 16), // "electrodeChanged"
QT_MOC_LITERAL(18, 265, 17), // "shutdownAfterIdle"
QT_MOC_LITERAL(19, 283, 17), // "measurementRound1"
QT_MOC_LITERAL(20, 301, 15), // "treatmentRound1"
QT_MOC_LITERAL(21, 317, 17), // "measurementRound2"
QT_MOC_LITERAL(22, 335, 15), // "treatmentRound2"
QT_MOC_LITERAL(23, 351, 17), // "measurementRound3"
QT_MOC_LITERAL(24, 369, 15), // "treatmentRound3"
QT_MOC_LITERAL(25, 385, 17), // "measurementRound4"
QT_MOC_LITERAL(26, 403, 15), // "treatmentRound4"
QT_MOC_LITERAL(27, 419, 17), // "measurementRound5"
QT_MOC_LITERAL(28, 437, 11), // "openTxtFile"
QT_MOC_LITERAL(29, 449, 12), // "onSessionEnd"
QT_MOC_LITERAL(30, 462, 17) // "onSessionEndEarly"

    },
    "MainWindow\0sessionStart\0\0endSessionEarly\0"
    "sessionPausedResumed\0sessionStartCheck\0"
    "updateBatteryLevel\0level\0batteryLow\0"
    "batteryCriticallyLow\0batteryNone\0"
    "powerOff\0confirmButtonPressed\0"
    "playButtonPressed\0pauseButtonPressed\0"
    "stopButtonPressed\0generateGraph\0"
    "electrodeChanged\0shutdownAfterIdle\0"
    "measurementRound1\0treatmentRound1\0"
    "measurementRound2\0treatmentRound2\0"
    "measurementRound3\0treatmentRound3\0"
    "measurementRound4\0treatmentRound4\0"
    "measurementRound5\0openTxtFile\0"
    "onSessionEnd\0onSessionEndEarly"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  154,    2, 0x06 /* Public */,
       3,    0,  155,    2, 0x06 /* Public */,
       4,    0,  156,    2, 0x06 /* Public */,
       5,    0,  157,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    1,  158,    2, 0x08 /* Private */,
       8,    0,  161,    2, 0x08 /* Private */,
       9,    0,  162,    2, 0x08 /* Private */,
      10,    0,  163,    2, 0x08 /* Private */,
      11,    0,  164,    2, 0x08 /* Private */,
      12,    0,  165,    2, 0x08 /* Private */,
      13,    0,  166,    2, 0x08 /* Private */,
      14,    0,  167,    2, 0x08 /* Private */,
      15,    0,  168,    2, 0x08 /* Private */,
      16,    0,  169,    2, 0x08 /* Private */,
      17,    0,  170,    2, 0x08 /* Private */,
      18,    0,  171,    2, 0x08 /* Private */,
      19,    0,  172,    2, 0x08 /* Private */,
      20,    0,  173,    2, 0x08 /* Private */,
      21,    0,  174,    2, 0x08 /* Private */,
      22,    0,  175,    2, 0x08 /* Private */,
      23,    0,  176,    2, 0x08 /* Private */,
      24,    0,  177,    2, 0x08 /* Private */,
      25,    0,  178,    2, 0x08 /* Private */,
      26,    0,  179,    2, 0x08 /* Private */,
      27,    0,  180,    2, 0x08 /* Private */,
      28,    0,  181,    2, 0x08 /* Private */,
      29,    0,  182,    2, 0x08 /* Private */,
      30,    0,  183,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->sessionStart(); break;
        case 1: _t->endSessionEarly(); break;
        case 2: _t->sessionPausedResumed(); break;
        case 3: _t->sessionStartCheck(); break;
        case 4: _t->updateBatteryLevel((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->batteryLow(); break;
        case 6: _t->batteryCriticallyLow(); break;
        case 7: _t->batteryNone(); break;
        case 8: _t->powerOff(); break;
        case 9: _t->confirmButtonPressed(); break;
        case 10: _t->playButtonPressed(); break;
        case 11: _t->pauseButtonPressed(); break;
        case 12: _t->stopButtonPressed(); break;
        case 13: _t->generateGraph(); break;
        case 14: _t->electrodeChanged(); break;
        case 15: _t->shutdownAfterIdle(); break;
        case 16: _t->measurementRound1(); break;
        case 17: _t->treatmentRound1(); break;
        case 18: _t->measurementRound2(); break;
        case 19: _t->treatmentRound2(); break;
        case 20: _t->measurementRound3(); break;
        case 21: _t->treatmentRound3(); break;
        case 22: _t->measurementRound4(); break;
        case 23: _t->treatmentRound4(); break;
        case 24: _t->measurementRound5(); break;
        case 25: _t->openTxtFile(); break;
        case 26: _t->onSessionEnd(); break;
        case 27: _t->onSessionEndEarly(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::sessionStart)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::endSessionEarly)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::sessionPausedResumed)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::sessionStartCheck)) {
                *result = 3;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 28;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::sessionStart()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void MainWindow::endSessionEarly()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void MainWindow::sessionPausedResumed()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void MainWindow::sessionStartCheck()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
