/********************************************************************************
** Form generated from reading UI file 'graphwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GRAPHWINDOW_H
#define UI_GRAPHWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GraphWindow
{
public:
    QGraphicsView *graphicsView;
    QLabel *label_min;
    QLabel *label_max;
    QLabel *label_hz;

    void setupUi(QWidget *GraphWindow)
    {
        if (GraphWindow->objectName().isEmpty())
            GraphWindow->setObjectName(QString::fromUtf8("GraphWindow"));
        GraphWindow->resize(744, 271);
        graphicsView = new QGraphicsView(GraphWindow);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));
        graphicsView->setGeometry(QRect(90, 10, 641, 251));
        label_min = new QLabel(GraphWindow);
        label_min->setObjectName(QString::fromUtf8("label_min"));
        label_min->setGeometry(QRect(5, 240, 71, 20));
        label_min->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_max = new QLabel(GraphWindow);
        label_max->setObjectName(QString::fromUtf8("label_max"));
        label_max->setGeometry(QRect(10, 10, 71, 20));
        label_max->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_hz = new QLabel(GraphWindow);
        label_hz->setObjectName(QString::fromUtf8("label_hz"));
        label_hz->setGeometry(QRect(50, 120, 31, 17));
        label_hz->setLayoutDirection(Qt::LeftToRight);
        label_hz->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        retranslateUi(GraphWindow);

        QMetaObject::connectSlotsByName(GraphWindow);
    } // setupUi

    void retranslateUi(QWidget *GraphWindow)
    {
        GraphWindow->setWindowTitle(QCoreApplication::translate("GraphWindow", "Form", nullptr));
        label_min->setText(QCoreApplication::translate("GraphWindow", "0", nullptr));
        label_max->setText(QCoreApplication::translate("GraphWindow", "30", nullptr));
        label_hz->setText(QCoreApplication::translate("GraphWindow", "(Hz)", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GraphWindow: public Ui_GraphWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GRAPHWINDOW_H
