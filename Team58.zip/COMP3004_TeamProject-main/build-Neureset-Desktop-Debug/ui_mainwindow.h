/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QListWidget *list_options;
    QPushButton *btn_power;
    QLabel *light_contactLost;
    QLabel *light_treatmentSignal;
    QLabel *light_contact;
    QProgressBar *battery;
    QLabel *label_battery;
    QPushButton *button_select;
    QPushButton *btn_pause;
    QPushButton *btn_play;
    QPushButton *btn_stop;
    QDateTimeEdit *dateTimeEdit;
    QLabel *label_dialogue;
    QLabel *label_dateTime;
    QLabel *label_sessionTimer;
    QLabel *timer_session;
    QLabel *label_electrode_1;
    QLabel *label_electrode_2;
    QLabel *label_electrode_3;
    QLabel *label_electrode_4;
    QLabel *label_electrode_6;
    QLabel *label_electrode_5;
    QLabel *label_electrode_7;
    QLabel *label_electrode_8;
    QLabel *label_electrode_9;
    QLabel *label_electrode_10;
    QLabel *label_electrode_17;
    QLabel *label_electrode_15;
    QLabel *label_electrode_18;
    QLabel *label_electrode_12;
    QLabel *label_electrode_19;
    QLabel *label_electrode_11;
    QLabel *label_electrode_13;
    QLabel *label_electrode_14;
    QLabel *label_electrode_20;
    QLabel *label_electrode_16;
    QLabel *label_electrode_21;
    QPushButton *btn_electrode_11;
    QPushButton *btn_electrode_12;
    QPushButton *btn_electrode_14;
    QPushButton *btn_electrode_13;
    QPushButton *btn_electrode_16;
    QPushButton *btn_electrode_15;
    QPushButton *btn_electrode_17;
    QPushButton *btn_electrode_18;
    QPushButton *btn_electrode_8;
    QPushButton *btn_electrode_2;
    QPushButton *btn_electrode_1;
    QPushButton *btn_electrode_5;
    QPushButton *btn_electrode_7;
    QPushButton *btn_electrode_3;
    QPushButton *btn_electrode_4;
    QPushButton *btn_electrode_6;
    QPushButton *btn_electrode_21;
    QPushButton *btn_electrode_20;
    QPushButton *btn_electrode_19;
    QPushButton *btn_electrode_10;
    QPushButton *btn_electrode_9;
    QPushButton *btn_generate_graph;
    QProgressBar *progressBar_session;
    QLabel *label_session_progress;
    QListWidget *list_graphs;
    QLabel *label_graph_list;
    QMenuBar *menubar;
    QMenu *menuNeureset_Direct_Neurofeedback_EEG_device_Prototype;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(677, 577);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: rgb(229, 212, 206);"));
        MainWindow->setIconSize(QSize(12, 12));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        list_options = new QListWidget(centralwidget);
        QFont font;
        font.setPointSize(15);
        font.setKerning(true);
        QListWidgetItem *__qlistwidgetitem = new QListWidgetItem(list_options);
        __qlistwidgetitem->setTextAlignment(Qt::AlignCenter);
        __qlistwidgetitem->setFont(font);
        QFont font1;
        font1.setPointSize(15);
        QListWidgetItem *__qlistwidgetitem1 = new QListWidgetItem(list_options);
        __qlistwidgetitem1->setTextAlignment(Qt::AlignCenter);
        __qlistwidgetitem1->setFont(font1);
        QFont font2;
        font2.setPointSize(15);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setUnderline(false);
        font2.setWeight(50);
        font2.setStrikeOut(false);
        font2.setKerning(true);
        font2.setStyleStrategy(QFont::PreferDefault);
        QListWidgetItem *__qlistwidgetitem2 = new QListWidgetItem(list_options);
        __qlistwidgetitem2->setTextAlignment(Qt::AlignCenter);
        __qlistwidgetitem2->setFont(font2);
        list_options->setObjectName(QString::fromUtf8("list_options"));
        list_options->setEnabled(true);
        list_options->setGeometry(QRect(400, 360, 251, 81));
        list_options->setLayoutDirection(Qt::LeftToRight);
        btn_power = new QPushButton(centralwidget);
        btn_power->setObjectName(QString::fromUtf8("btn_power"));
        btn_power->setGeometry(QRect(580, 10, 71, 71));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/resources/icons/power-button.png"), QSize(), QIcon::Normal, QIcon::Off);
        btn_power->setIcon(icon);
        btn_power->setIconSize(QSize(32, 32));
        light_contactLost = new QLabel(centralwidget);
        light_contactLost->setObjectName(QString::fromUtf8("light_contactLost"));
        light_contactLost->setGeometry(QRect(90, 10, 31, 71));
        light_contactLost->setStyleSheet(QString::fromUtf8("background-color: rgb(50, 0, 0);"));
        light_treatmentSignal = new QLabel(centralwidget);
        light_treatmentSignal->setObjectName(QString::fromUtf8("light_treatmentSignal"));
        light_treatmentSignal->setGeometry(QRect(50, 10, 31, 71));
        light_treatmentSignal->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 50, 0);"));
        light_contact = new QLabel(centralwidget);
        light_contact->setObjectName(QString::fromUtf8("light_contact"));
        light_contact->setGeometry(QRect(10, 10, 31, 71));
        light_contact->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 50);"));
        battery = new QProgressBar(centralwidget);
        battery->setObjectName(QString::fromUtf8("battery"));
        battery->setGeometry(QRect(160, 60, 411, 21));
        battery->setStyleSheet(QString::fromUtf8("QProgressBar{margin: 0px; }\n"
"background-color: rgb(94, 92, 100);\n"
""));
        battery->setValue(37);
        battery->setAlignment(Qt::AlignCenter);
        battery->setTextVisible(true);
        battery->setOrientation(Qt::Horizontal);
        battery->setInvertedAppearance(false);
        battery->setTextDirection(QProgressBar::TopToBottom);
        label_battery = new QLabel(centralwidget);
        label_battery->setObjectName(QString::fromUtf8("label_battery"));
        label_battery->setGeometry(QRect(130, 50, 21, 31));
        label_battery->setPixmap(QPixmap(QString::fromUtf8(":/resources/icons/battery.png")));
        label_battery->setScaledContents(true);
        button_select = new QPushButton(centralwidget);
        button_select->setObjectName(QString::fromUtf8("button_select"));
        button_select->setGeometry(QRect(400, 450, 251, 31));
        btn_pause = new QPushButton(centralwidget);
        btn_pause->setObjectName(QString::fromUtf8("btn_pause"));
        btn_pause->setEnabled(false);
        btn_pause->setGeometry(QRect(490, 260, 71, 51));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/resources/icons/pause.png"), QSize(), QIcon::Normal, QIcon::Off);
        btn_pause->setIcon(icon1);
        btn_pause->setIconSize(QSize(32, 32));
        btn_play = new QPushButton(centralwidget);
        btn_play->setObjectName(QString::fromUtf8("btn_play"));
        btn_play->setEnabled(false);
        btn_play->setGeometry(QRect(580, 260, 71, 51));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/resources/icons/play.png"), QSize(), QIcon::Normal, QIcon::Off);
        btn_play->setIcon(icon2);
        btn_play->setIconSize(QSize(32, 32));
        btn_stop = new QPushButton(centralwidget);
        btn_stop->setObjectName(QString::fromUtf8("btn_stop"));
        btn_stop->setEnabled(false);
        btn_stop->setGeometry(QRect(400, 260, 71, 51));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/resources/icons/stop.png"), QSize(), QIcon::Normal, QIcon::Off);
        btn_stop->setIcon(icon3);
        btn_stop->setIconSize(QSize(32, 32));
        dateTimeEdit = new QDateTimeEdit(centralwidget);
        dateTimeEdit->setObjectName(QString::fromUtf8("dateTimeEdit"));
        dateTimeEdit->setEnabled(false);
        dateTimeEdit->setGeometry(QRect(300, 10, 271, 41));
        QFont font3;
        font3.setFamily(QString::fromUtf8("DejaVu Sans"));
        font3.setPointSize(22);
        dateTimeEdit->setFont(font3);
        label_dialogue = new QLabel(centralwidget);
        label_dialogue->setObjectName(QString::fromUtf8("label_dialogue"));
        label_dialogue->setGeometry(QRect(410, 320, 251, 31));
        QFont font4;
        font4.setFamily(QString::fromUtf8("DejaVu Sans"));
        font4.setPointSize(14);
        label_dialogue->setFont(font4);
        label_dialogue->setAutoFillBackground(false);
        label_dialogue->setStyleSheet(QString::fromUtf8(""));
        label_dialogue->setTextFormat(Qt::AutoText);
        label_dialogue->setScaledContents(true);
        label_dialogue->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_dateTime = new QLabel(centralwidget);
        label_dateTime->setObjectName(QString::fromUtf8("label_dateTime"));
        label_dateTime->setGeometry(QRect(130, 10, 161, 41));
        QFont font5;
        font5.setFamily(QString::fromUtf8("DejaVu Sans"));
        font5.setPointSize(18);
        label_dateTime->setFont(font5);
        label_sessionTimer = new QLabel(centralwidget);
        label_sessionTimer->setObjectName(QString::fromUtf8("label_sessionTimer"));
        label_sessionTimer->setEnabled(false);
        label_sessionTimer->setGeometry(QRect(400, 90, 251, 31));
        label_sessionTimer->setFont(font4);
        label_sessionTimer->setAlignment(Qt::AlignCenter);
        timer_session = new QLabel(centralwidget);
        timer_session->setObjectName(QString::fromUtf8("timer_session"));
        timer_session->setEnabled(false);
        timer_session->setGeometry(QRect(400, 120, 251, 71));
        QFont font6;
        font6.setFamily(QString::fromUtf8("DejaVu Sans"));
        font6.setPointSize(52);
        timer_session->setFont(font6);
        timer_session->setLayoutDirection(Qt::LeftToRight);
        timer_session->setAlignment(Qt::AlignCenter);
        label_electrode_1 = new QLabel(centralwidget);
        label_electrode_1->setObjectName(QString::fromUtf8("label_electrode_1"));
        label_electrode_1->setGeometry(QRect(300, 90, 91, 31));
        label_electrode_2 = new QLabel(centralwidget);
        label_electrode_2->setObjectName(QString::fromUtf8("label_electrode_2"));
        label_electrode_2->setGeometry(QRect(300, 120, 91, 31));
        label_electrode_3 = new QLabel(centralwidget);
        label_electrode_3->setObjectName(QString::fromUtf8("label_electrode_3"));
        label_electrode_3->setGeometry(QRect(300, 150, 91, 31));
        label_electrode_4 = new QLabel(centralwidget);
        label_electrode_4->setObjectName(QString::fromUtf8("label_electrode_4"));
        label_electrode_4->setGeometry(QRect(300, 180, 91, 31));
        label_electrode_6 = new QLabel(centralwidget);
        label_electrode_6->setObjectName(QString::fromUtf8("label_electrode_6"));
        label_electrode_6->setGeometry(QRect(300, 240, 91, 31));
        label_electrode_5 = new QLabel(centralwidget);
        label_electrode_5->setObjectName(QString::fromUtf8("label_electrode_5"));
        label_electrode_5->setGeometry(QRect(300, 210, 91, 31));
        label_electrode_7 = new QLabel(centralwidget);
        label_electrode_7->setObjectName(QString::fromUtf8("label_electrode_7"));
        label_electrode_7->setGeometry(QRect(300, 270, 91, 31));
        label_electrode_8 = new QLabel(centralwidget);
        label_electrode_8->setObjectName(QString::fromUtf8("label_electrode_8"));
        label_electrode_8->setGeometry(QRect(300, 300, 91, 31));
        label_electrode_9 = new QLabel(centralwidget);
        label_electrode_9->setObjectName(QString::fromUtf8("label_electrode_9"));
        label_electrode_9->setGeometry(QRect(300, 330, 91, 31));
        label_electrode_10 = new QLabel(centralwidget);
        label_electrode_10->setObjectName(QString::fromUtf8("label_electrode_10"));
        label_electrode_10->setGeometry(QRect(300, 360, 91, 31));
        label_electrode_17 = new QLabel(centralwidget);
        label_electrode_17->setObjectName(QString::fromUtf8("label_electrode_17"));
        label_electrode_17->setGeometry(QRect(100, 270, 91, 31));
        label_electrode_15 = new QLabel(centralwidget);
        label_electrode_15->setObjectName(QString::fromUtf8("label_electrode_15"));
        label_electrode_15->setGeometry(QRect(100, 210, 91, 31));
        label_electrode_18 = new QLabel(centralwidget);
        label_electrode_18->setObjectName(QString::fromUtf8("label_electrode_18"));
        label_electrode_18->setGeometry(QRect(100, 300, 91, 31));
        label_electrode_12 = new QLabel(centralwidget);
        label_electrode_12->setObjectName(QString::fromUtf8("label_electrode_12"));
        label_electrode_12->setGeometry(QRect(100, 120, 91, 31));
        label_electrode_19 = new QLabel(centralwidget);
        label_electrode_19->setObjectName(QString::fromUtf8("label_electrode_19"));
        label_electrode_19->setGeometry(QRect(100, 330, 91, 31));
        label_electrode_11 = new QLabel(centralwidget);
        label_electrode_11->setObjectName(QString::fromUtf8("label_electrode_11"));
        label_electrode_11->setGeometry(QRect(100, 90, 91, 31));
        label_electrode_13 = new QLabel(centralwidget);
        label_electrode_13->setObjectName(QString::fromUtf8("label_electrode_13"));
        label_electrode_13->setGeometry(QRect(100, 150, 91, 31));
        label_electrode_14 = new QLabel(centralwidget);
        label_electrode_14->setObjectName(QString::fromUtf8("label_electrode_14"));
        label_electrode_14->setGeometry(QRect(100, 180, 91, 31));
        label_electrode_20 = new QLabel(centralwidget);
        label_electrode_20->setObjectName(QString::fromUtf8("label_electrode_20"));
        label_electrode_20->setGeometry(QRect(100, 360, 91, 31));
        label_electrode_16 = new QLabel(centralwidget);
        label_electrode_16->setObjectName(QString::fromUtf8("label_electrode_16"));
        label_electrode_16->setGeometry(QRect(100, 240, 91, 31));
        label_electrode_21 = new QLabel(centralwidget);
        label_electrode_21->setObjectName(QString::fromUtf8("label_electrode_21"));
        label_electrode_21->setGeometry(QRect(100, 390, 91, 31));
        btn_electrode_11 = new QPushButton(centralwidget);
        btn_electrode_11->setObjectName(QString::fromUtf8("btn_electrode_11"));
        btn_electrode_11->setGeometry(QRect(10, 90, 83, 25));
        btn_electrode_11->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_12 = new QPushButton(centralwidget);
        btn_electrode_12->setObjectName(QString::fromUtf8("btn_electrode_12"));
        btn_electrode_12->setGeometry(QRect(10, 120, 83, 25));
        btn_electrode_12->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_14 = new QPushButton(centralwidget);
        btn_electrode_14->setObjectName(QString::fromUtf8("btn_electrode_14"));
        btn_electrode_14->setGeometry(QRect(10, 180, 83, 25));
        btn_electrode_14->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_13 = new QPushButton(centralwidget);
        btn_electrode_13->setObjectName(QString::fromUtf8("btn_electrode_13"));
        btn_electrode_13->setGeometry(QRect(10, 150, 83, 25));
        btn_electrode_13->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_16 = new QPushButton(centralwidget);
        btn_electrode_16->setObjectName(QString::fromUtf8("btn_electrode_16"));
        btn_electrode_16->setGeometry(QRect(10, 240, 83, 25));
        btn_electrode_16->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_15 = new QPushButton(centralwidget);
        btn_electrode_15->setObjectName(QString::fromUtf8("btn_electrode_15"));
        btn_electrode_15->setGeometry(QRect(10, 210, 83, 25));
        btn_electrode_15->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_17 = new QPushButton(centralwidget);
        btn_electrode_17->setObjectName(QString::fromUtf8("btn_electrode_17"));
        btn_electrode_17->setGeometry(QRect(10, 270, 83, 25));
        btn_electrode_17->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_18 = new QPushButton(centralwidget);
        btn_electrode_18->setObjectName(QString::fromUtf8("btn_electrode_18"));
        btn_electrode_18->setGeometry(QRect(10, 300, 83, 25));
        btn_electrode_18->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_8 = new QPushButton(centralwidget);
        btn_electrode_8->setObjectName(QString::fromUtf8("btn_electrode_8"));
        btn_electrode_8->setGeometry(QRect(210, 300, 83, 25));
        btn_electrode_8->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_2 = new QPushButton(centralwidget);
        btn_electrode_2->setObjectName(QString::fromUtf8("btn_electrode_2"));
        btn_electrode_2->setGeometry(QRect(210, 120, 83, 25));
        btn_electrode_2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_1 = new QPushButton(centralwidget);
        btn_electrode_1->setObjectName(QString::fromUtf8("btn_electrode_1"));
        btn_electrode_1->setGeometry(QRect(210, 90, 83, 25));
        btn_electrode_1->setMouseTracking(false);
        btn_electrode_1->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_1->setAutoRepeatInterval(100);
        btn_electrode_5 = new QPushButton(centralwidget);
        btn_electrode_5->setObjectName(QString::fromUtf8("btn_electrode_5"));
        btn_electrode_5->setGeometry(QRect(210, 210, 83, 25));
        btn_electrode_5->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_7 = new QPushButton(centralwidget);
        btn_electrode_7->setObjectName(QString::fromUtf8("btn_electrode_7"));
        btn_electrode_7->setGeometry(QRect(210, 270, 83, 25));
        btn_electrode_7->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_3 = new QPushButton(centralwidget);
        btn_electrode_3->setObjectName(QString::fromUtf8("btn_electrode_3"));
        btn_electrode_3->setGeometry(QRect(210, 150, 83, 25));
        btn_electrode_3->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_4 = new QPushButton(centralwidget);
        btn_electrode_4->setObjectName(QString::fromUtf8("btn_electrode_4"));
        btn_electrode_4->setGeometry(QRect(210, 180, 83, 25));
        btn_electrode_4->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_6 = new QPushButton(centralwidget);
        btn_electrode_6->setObjectName(QString::fromUtf8("btn_electrode_6"));
        btn_electrode_6->setGeometry(QRect(210, 240, 83, 25));
        btn_electrode_6->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_21 = new QPushButton(centralwidget);
        btn_electrode_21->setObjectName(QString::fromUtf8("btn_electrode_21"));
        btn_electrode_21->setGeometry(QRect(10, 390, 83, 25));
        btn_electrode_21->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_20 = new QPushButton(centralwidget);
        btn_electrode_20->setObjectName(QString::fromUtf8("btn_electrode_20"));
        btn_electrode_20->setGeometry(QRect(10, 360, 83, 25));
        btn_electrode_20->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_19 = new QPushButton(centralwidget);
        btn_electrode_19->setObjectName(QString::fromUtf8("btn_electrode_19"));
        btn_electrode_19->setGeometry(QRect(10, 330, 83, 25));
        btn_electrode_19->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_10 = new QPushButton(centralwidget);
        btn_electrode_10->setObjectName(QString::fromUtf8("btn_electrode_10"));
        btn_electrode_10->setGeometry(QRect(210, 360, 83, 25));
        btn_electrode_10->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_electrode_9 = new QPushButton(centralwidget);
        btn_electrode_9->setObjectName(QString::fromUtf8("btn_electrode_9"));
        btn_electrode_9->setGeometry(QRect(210, 330, 83, 25));
        btn_electrode_9->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        btn_generate_graph = new QPushButton(centralwidget);
        btn_generate_graph->setObjectName(QString::fromUtf8("btn_generate_graph"));
        btn_generate_graph->setGeometry(QRect(400, 490, 251, 41));
        progressBar_session = new QProgressBar(centralwidget);
        progressBar_session->setObjectName(QString::fromUtf8("progressBar_session"));
        progressBar_session->setEnabled(false);
        progressBar_session->setGeometry(QRect(400, 190, 251, 21));
        progressBar_session->setValue(0);
        label_session_progress = new QLabel(centralwidget);
        label_session_progress->setObjectName(QString::fromUtf8("label_session_progress"));
        label_session_progress->setEnabled(false);
        label_session_progress->setGeometry(QRect(400, 220, 251, 41));
        list_graphs = new QListWidget(centralwidget);
        list_graphs->setObjectName(QString::fromUtf8("list_graphs"));
        list_graphs->setGeometry(QRect(10, 430, 381, 101));
        label_graph_list = new QLabel(centralwidget);
        label_graph_list->setObjectName(QString::fromUtf8("label_graph_list"));
        label_graph_list->setGeometry(QRect(240, 410, 121, 17));
        label_graph_list->setAlignment(Qt::AlignCenter);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 677, 22));
        menuNeureset_Direct_Neurofeedback_EEG_device_Prototype = new QMenu(menubar);
        menuNeureset_Direct_Neurofeedback_EEG_device_Prototype->setObjectName(QString::fromUtf8("menuNeureset_Direct_Neurofeedback_EEG_device_Prototype"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuNeureset_Direct_Neurofeedback_EEG_device_Prototype->menuAction());

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));

        const bool __sortingEnabled = list_options->isSortingEnabled();
        list_options->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = list_options->item(0);
        ___qlistwidgetitem->setText(QCoreApplication::translate("MainWindow", "NEW SESSION", nullptr));
        QListWidgetItem *___qlistwidgetitem1 = list_options->item(1);
        ___qlistwidgetitem1->setText(QCoreApplication::translate("MainWindow", "SESSION LOG", nullptr));
        QListWidgetItem *___qlistwidgetitem2 = list_options->item(2);
        ___qlistwidgetitem2->setText(QCoreApplication::translate("MainWindow", "TIME AND DATE", nullptr));
        list_options->setSortingEnabled(__sortingEnabled);

        btn_power->setText(QString());
        light_contactLost->setText(QString());
        light_treatmentSignal->setText(QString());
        light_contact->setText(QString());
        label_battery->setText(QString());
        button_select->setText(QCoreApplication::translate("MainWindow", "Confirm", nullptr));
        btn_pause->setText(QString());
        btn_play->setText(QString());
        btn_stop->setText(QString());
        label_dialogue->setText(QCoreApplication::translate("MainWindow", "Please choose an option", nullptr));
        label_dateTime->setText(QCoreApplication::translate("MainWindow", "System Time", nullptr));
        label_sessionTimer->setText(QCoreApplication::translate("MainWindow", "Session Remain Time", nullptr));
        timer_session->setText(QCoreApplication::translate("MainWindow", "00:00", nullptr));
        label_electrode_1->setText(QCoreApplication::translate("MainWindow", "Electrode 1", nullptr));
        label_electrode_2->setText(QCoreApplication::translate("MainWindow", "Electrode 2", nullptr));
        label_electrode_3->setText(QCoreApplication::translate("MainWindow", "Electrode 3", nullptr));
        label_electrode_4->setText(QCoreApplication::translate("MainWindow", "Electrode 4", nullptr));
        label_electrode_6->setText(QCoreApplication::translate("MainWindow", "Electrode 6", nullptr));
        label_electrode_5->setText(QCoreApplication::translate("MainWindow", "Electrode 5", nullptr));
        label_electrode_7->setText(QCoreApplication::translate("MainWindow", "Electrode 7", nullptr));
        label_electrode_8->setText(QCoreApplication::translate("MainWindow", "Electrode 8", nullptr));
        label_electrode_9->setText(QCoreApplication::translate("MainWindow", "Electrode 9", nullptr));
        label_electrode_10->setText(QCoreApplication::translate("MainWindow", "Electrode 10", nullptr));
        label_electrode_17->setText(QCoreApplication::translate("MainWindow", "Electrode 17", nullptr));
        label_electrode_15->setText(QCoreApplication::translate("MainWindow", "Electrode 15", nullptr));
        label_electrode_18->setText(QCoreApplication::translate("MainWindow", "Electrode 18", nullptr));
        label_electrode_12->setText(QCoreApplication::translate("MainWindow", "Electrode 12", nullptr));
        label_electrode_19->setText(QCoreApplication::translate("MainWindow", "Electrode 19", nullptr));
        label_electrode_11->setText(QCoreApplication::translate("MainWindow", "Electrode 11", nullptr));
        label_electrode_13->setText(QCoreApplication::translate("MainWindow", "Electrode 13", nullptr));
        label_electrode_14->setText(QCoreApplication::translate("MainWindow", "Electrode 14", nullptr));
        label_electrode_20->setText(QCoreApplication::translate("MainWindow", "Electrode 20", nullptr));
        label_electrode_16->setText(QCoreApplication::translate("MainWindow", "Electrode 16", nullptr));
        label_electrode_21->setText(QCoreApplication::translate("MainWindow", "Electrode 21", nullptr));
        btn_electrode_11->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_12->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_14->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_13->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_16->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_15->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_17->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_18->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_8->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_2->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_1->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_5->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_7->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_3->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_4->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_6->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_21->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_20->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_19->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_10->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_electrode_9->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        btn_generate_graph->setText(QCoreApplication::translate("MainWindow", "Display Graph", nullptr));
        label_session_progress->setText(QCoreApplication::translate("MainWindow", "Waiting for session to start...", nullptr));
        label_graph_list->setText(QCoreApplication::translate("MainWindow", "Text", nullptr));
        menuNeureset_Direct_Neurofeedback_EEG_device_Prototype->setTitle(QCoreApplication::translate("MainWindow", "Neureset - Direct Neurofeedback EEG device Prototype", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
