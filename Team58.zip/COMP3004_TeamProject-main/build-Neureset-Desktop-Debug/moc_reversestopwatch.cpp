/****************************************************************************
** Meta object code from reading C++ file 'reversestopwatch.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../Neureset/reversestopwatch.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'reversestopwatch.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_reverseStopwatch_t {
    QByteArrayData data[12];
    char stringdata0[172];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_reverseStopwatch_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_reverseStopwatch_t qt_meta_stringdata_reverseStopwatch = {
    {
QT_MOC_LITERAL(0, 0, 16), // "reverseStopwatch"
QT_MOC_LITERAL(1, 17, 7), // "timeout"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 15), // "seconds5Elapsed"
QT_MOC_LITERAL(4, 42, 15), // "seconds6Elapsed"
QT_MOC_LITERAL(5, 58, 16), // "seconds11Elapsed"
QT_MOC_LITERAL(6, 75, 16), // "seconds12Elapsed"
QT_MOC_LITERAL(7, 92, 16), // "seconds17Elapsed"
QT_MOC_LITERAL(8, 109, 16), // "seconds18Elapsed"
QT_MOC_LITERAL(9, 126, 16), // "seconds23Elapsed"
QT_MOC_LITERAL(10, 143, 16), // "seconds24Elapsed"
QT_MOC_LITERAL(11, 160, 11) // "updateTimer"

    },
    "reverseStopwatch\0timeout\0\0seconds5Elapsed\0"
    "seconds6Elapsed\0seconds11Elapsed\0"
    "seconds12Elapsed\0seconds17Elapsed\0"
    "seconds18Elapsed\0seconds23Elapsed\0"
    "seconds24Elapsed\0updateTimer"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_reverseStopwatch[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       9,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   64,    2, 0x06 /* Public */,
       3,    0,   65,    2, 0x06 /* Public */,
       4,    0,   66,    2, 0x06 /* Public */,
       5,    0,   67,    2, 0x06 /* Public */,
       6,    0,   68,    2, 0x06 /* Public */,
       7,    0,   69,    2, 0x06 /* Public */,
       8,    0,   70,    2, 0x06 /* Public */,
       9,    0,   71,    2, 0x06 /* Public */,
      10,    0,   72,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      11,    0,   73,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void reverseStopwatch::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<reverseStopwatch *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->timeout(); break;
        case 1: _t->seconds5Elapsed(); break;
        case 2: _t->seconds6Elapsed(); break;
        case 3: _t->seconds11Elapsed(); break;
        case 4: _t->seconds12Elapsed(); break;
        case 5: _t->seconds17Elapsed(); break;
        case 6: _t->seconds18Elapsed(); break;
        case 7: _t->seconds23Elapsed(); break;
        case 8: _t->seconds24Elapsed(); break;
        case 9: _t->updateTimer(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (reverseStopwatch::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&reverseStopwatch::timeout)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (reverseStopwatch::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&reverseStopwatch::seconds5Elapsed)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (reverseStopwatch::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&reverseStopwatch::seconds6Elapsed)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (reverseStopwatch::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&reverseStopwatch::seconds11Elapsed)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (reverseStopwatch::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&reverseStopwatch::seconds12Elapsed)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (reverseStopwatch::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&reverseStopwatch::seconds17Elapsed)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (reverseStopwatch::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&reverseStopwatch::seconds18Elapsed)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (reverseStopwatch::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&reverseStopwatch::seconds23Elapsed)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (reverseStopwatch::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&reverseStopwatch::seconds24Elapsed)) {
                *result = 8;
                return;
            }
        }
    }
    (void)_a;
}

QT_INIT_METAOBJECT const QMetaObject reverseStopwatch::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_reverseStopwatch.data,
    qt_meta_data_reverseStopwatch,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *reverseStopwatch::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *reverseStopwatch::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_reverseStopwatch.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int reverseStopwatch::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void reverseStopwatch::timeout()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void reverseStopwatch::seconds5Elapsed()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void reverseStopwatch::seconds6Elapsed()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void reverseStopwatch::seconds11Elapsed()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void reverseStopwatch::seconds12Elapsed()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void reverseStopwatch::seconds17Elapsed()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void reverseStopwatch::seconds18Elapsed()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void reverseStopwatch::seconds23Elapsed()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void reverseStopwatch::seconds24Elapsed()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
